<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>index</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <div class="body">
        
        <div class="header">
            <div class="header2">
                <a href="shopkeeperlogin.php">ShopKeeper</a>
                <a href="managementlogin.php">Management</a>
            </div>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br>
        <div class="content">
           <b> <p class="animated-text">Business Report PORTAL</p></b>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    </div>
</body>
</html>
