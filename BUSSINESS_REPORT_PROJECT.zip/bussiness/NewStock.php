<?php
include("connection.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>stock</title>
    <style>
        body {
          margin: 0;
          font-family: "Lato", sans-serif;
        }
        
        .sidebar {
          margin: 0;
          padding: 0;
          width: 250px;
          background-color: grey;
          position: fixed;
          height: 100%;
          overflow: auto;
        }
        
        .sidebar a {
          display: block;
          color: black;
          padding: 16px;
          text-decoration: none;
          font-size: 30px;

        }
         
        .sidebar a.active {
          background-color: #04AA6D;
          color: white;
        }
        
        .sidebar a:hover:not(.active) {
          background-color: #555;
          color: white;
        }
        
        .customers{
          display:block;
          width: 100%;
          height:100%;
          background-color: whitesmoke;
          margin-left: 30px;
          margin-top: 60px;
          
        
        }
        .customers td{
        
          background-color:white;
          color:black;
         padding: 5px 75px;
          text-align:left;
          font-size: 20px;
         
          
        }
        .customers th{
          
          background-color:white;
          color:black;
         padding: 5px 75px;
          text-align:left;
          font-size: 25px;
        }
          
        .customers button{
          background:black;
          color:white;
          font-size: 20px;

        }

        
        </style>
         
</head>
<body>
<?php
include("seller.php");
?>


<!-------my side bar here-->
   
      <table class="customers">
  <thead>
    <tr>
      <th scope="col">Number</th>
      <th scope="col">Type</th>
      <th scope="col">Quantity</th>
      <th scope="col">Cost</th>
      <th scope="col">Date</th>
      
    </tr>
  </thead>

  <tbody>

<!--------------SELECT ALL USERS-------->
  <?php
     $count=1;
    
      $select_all_goods = "select * from stock  order by id asc";

         $result = mysqli_query($conn,$select_all_goods);
                 $number = mysqli_num_rows($result);
                 if ($number > 0) {
                     while($row = mysqli_fetch_assoc($result)) {  ?>   
                        <tr>
            
              <td><?php echo $count++ ?></td>

               <td><?php echo $row['good'];?></td>

              <td><?php echo $row['quantity'];?></td>
              <td><?php echo $row['cost'];?></td>
              <td><?php echo $row['date'];?></td>


                      </tr>

             <?php } }  else {
             echo "0 results"; }?>


  </tbody>
</table>

     </div>
             </div>
        </div>
      </div>
      <!---ends-->
      


</body>
</html>