<?php
include("connection.php");

if(isset($_POST["update"])){

    $id =$_GET["id"];
    $good =$_POST["good"];
    
    $quantity =$_POST["quantity"];
    $cost =$_POST["cost"];
    $date =$_POST["date"];


 $update_good = "UPDATE sales SET  good='$good',quantity='$quantity',cost='$cost',date='$date'
    WHERE  id='$id'";

    if (mysqli_query($conn, $update_good)) {
           header("location:sold.php");
           exit();
    } else {
        echo "wrong updation try again";
    }
}
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Update</title>
    <style>
        .form {
            display: block;
            background-color:white;
            height:800px;
            width: 1600px;
            margin-left: 10px;
            padding-left: 50px;
            margin-top: 50px;
            position: fixed;
        }
        input, select {
            padding: 10px;
            color: black;
            background-color: transparent;
            margin-left: 0px;
            font-size: 25px;
            text-align: left;
            border-color:whitesmoke;
            width: 1500px;
            box-sizing: border-box; /* Ensure padding and border are included in the width */
        }
        h1 {
            font-size: 30px;
            text-align: center;
            color: black;
        }
    
        h2 {
            font-size: 30px;
        }
        p {
             color: purple;
        }
    </style>
  </head>
  <body>
  <?php
include("seller.php");
?>


  <div class="form">
    <form action="" method="post">
    <h1>please fill the box below</h1>
                <?php
                $select_good = "select * from  sales where id = '" .$_GET['id']. "'";
                $result = mysqli_query($conn,  $select_good);
                $number = mysqli_num_rows($result);
                 if ($number > 0) {
                     while($row = mysqli_fetch_assoc($result)) {  ?>   

      
      <br><br>
      <label><h2>*Good</h2></label>
      <input type="text" name="good" value="<?php echo $row['good']; ?>" placeholder="">
    
      <br>
      <label><h2>*Quantity</h2></label>
      <input type="text" name="quantity" value="<?php echo $row['quantity']; ?>" placeholder="">
     <br>
     <label><h2>*Cost</h2></label>
      <input type="text" name="cost" value="<?php echo $row['cost']; ?>"  placeholder="">
      <br>
     <label><h2>*Date</h2></label><br>
      <input type="date" name="date" value="<?php echo $row['date']; ?>" placeholder="">
     
      <br><br>
    

 


  
    <?php  } } ?>

  <button type="submit" name="update" class="btn btn-primary">Update</button>
  </div>

</form>


</div>
<div>
</div>
</div>
<br>
 
</div>







  </body>
</html>
