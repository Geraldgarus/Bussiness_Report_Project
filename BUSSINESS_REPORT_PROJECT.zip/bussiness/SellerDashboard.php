<?php
session_start();
include("connection.php");

// Function to calculate the sum of sales for a given period
function calculateSalesSum($conn, $startDate, $endDate)
{
    $query = "SELECT SUM(cost) AS total FROM sales WHERE date BETWEEN '$startDate' AND '$endDate'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    return $row['total'];
}

// Calculate daily sales
$dailySales = calculateSalesSum($conn, date('Y-m-d'), date('Y-m-d'));

// Calculate weekly sales (assuming the week starts from Monday)
$weekStartDate = date('Y-m-d', strtotime('last Monday'));
$weekEndDate = date('Y-m-d', strtotime('next Sunday'));
$weeklySales = calculateSalesSum($conn, $weekStartDate, $weekEndDate);

// Calculate monthly sales
$monthStartDate = date('Y-m-01');
$monthEndDate = date('Y-m-t');
$monthlySales = calculateSalesSum($conn, $monthStartDate, $monthEndDate);

// Calculate yearly sales
$yearStartDate = date('Y-01-01');
$yearEndDate = date('Y-12-31');
$yearlySales = calculateSalesSum($conn, $yearStartDate, $yearEndDate);
?>


<!DOCTYPE html>
<!-- Website - www.codingnepalweb.com -->
<html lang="en" dir="ltr">

<head>
  <meta charset="UTF-8" />
  <title>DASHBOARD</title>
  <link rel="stylesheet" href="hogo9.css" />
  <!-- Boxicons CDN Link -->
  <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <style>
    .box {
      background: #fff;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
      margin: 20px 0;
      animation: bounce 2s infinite; /* Apply bouncing animation */
    }

    .box:hover {
      animation: none; /* Stop animation on hover */
    }

    @keyframes bounce {
      0%, 20%, 50%, 80%, 100% {
        transform: translateY(0);
      }
      40% {
        transform: translateY(-30px);
      }
      60% {
        transform: translateY(-15px);
      }
    }
  </style>
  <!-- Boxicons CDN Link -->
  <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>

<body>
<?php
include("seller.php");

?>
<div class="home-content">
      <div class="overview-boxes">
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Sold</div>
            <div class="number">
            <?php
$countgoods = mysqli_query($conn, "select id from sales");
$user = mysqli_num_rows($countgoods);
if (empty($users) >= 0) { ?>
<?php echo $user; ?>
<?php } ?> items
            </div>
            <div class="indicator">
            <i class="bx bx-line-chart down"></i> 
              <span class="text">Today</span>
            </div>
          </div>
        
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">NewStock</div>
            <div class="number">
            <?php
$countgoods = mysqli_query($conn, "select id from stock");
$user = mysqli_num_rows($countgoods);
if (empty($users) >= 0) { ?>
<?php echo $user; ?>
<?php } ?> items
            </div>
            <div class="indicator">
            <i class="bx bx-package"></i>
              <span class="text">Today</span>
            </div>
          </div>
     
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">DailySales</div>
            <div class="number">
            $<div class="number"><?php echo $dailySales; ?></div>

            </div>
            <div class="indicator">
            <i class="bx bx-line-chart down"></i> 
              <span class="text">Today</span>
            </div>
          </div>
        
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">WeeklySales</div>
            <div class="number">
           $ <div class="number"><?php echo $weeklySales; ?></div>
                    
            </div>
            <div class="indicator">
            <i class="bx bx-line-chart down"></i> 
              <span class="text"> Week</span>
            </div>
          </div>
        </div>
      </div>
      <div class="center">
      </div>
    </div>
</body>

</html>

<div class="home-content">
  <div class="overview-boxes">
    <!-- Your PHP code for boxes goes here -->
  </div>
  <div class="center">
  </div>
</div>

<script>
  let sidebar = document.querySelector(".sidebar");
  let sidebarBtn = document.querySelector(".sidebarBtn");
  sidebarBtn.onclick = function() {
    sidebar.classList.toggle("active");
    if (sidebar.classList.contains("active")) {
      sidebarBtn.classList.replace("bx-menu", "bx-menu-alt-right");
    } else sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
  };
</script>
</body>

</html>
