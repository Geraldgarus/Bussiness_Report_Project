<?php
include("connection.php");

$id = $_REQUEST['id'];
$query_for_select_user_row = "DELETE FROM stock WHERE id= $id"; 

$result = mysqli_query($conn,$query_for_select_user_row);

header("Location:uploadedstock.php"); 
exit();

?>