<?php
session_start();
include("connection.php");

// Function to calculate the sum of sales for a given period (daily, weekly, monthly, yearly)
function calculateSalesForPeriod($conn, $startDate, $endDate)
{
    $query = "SELECT SUM(cost) AS total FROM sales WHERE date BETWEEN '$startDate' AND '$endDate'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    return $row['total'];
}

// Get the current date
$currentDate = date('Y-m-d');

// Calculate the daily sales for the current day
$dailySales = calculateSalesForPeriod($conn, $currentDate, $currentDate);

// Calculate the weekly sales for the current week
$currentWeekStart = date('Y-m-d', strtotime('last Monday', strtotime($currentDate)));
$currentWeekEnd = date('Y-m-d', strtotime('next Sunday', strtotime($currentDate)));
$weeklySales = calculateSalesForPeriod($conn, $currentWeekStart, $currentWeekEnd);

// Calculate the monthly sales for the current month
$currentMonthStart = date('Y-m-01', strtotime($currentDate));
$currentMonthEnd = date('Y-m-t', strtotime($currentDate));
$monthlySales = calculateSalesForPeriod($conn, $currentMonthStart, $currentMonthEnd);

// Calculate the yearly sales for the current year
$currentYearStart = date('Y-01-01', strtotime($currentDate));
$currentYearEnd = date('Y-12-31', strtotime($currentDate));
$yearlySales = calculateSalesForPeriod($conn, $currentYearStart, $currentYearEnd);
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8" />
    <title>DASHBOARD</title>
    <link rel="stylesheet" href="hogo8.css" />
    <!-- Boxicons CDN Link -->
    <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <style>
        .box {
            background: #fff;
            padding: 20px;
            border-radius: 100%;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
            margin: 20px 0;
            animation: bounce 2s infinite;
            /* Apply bouncing animation */
        }

        .box:hover {
            animation: none;
            /* Stop animation on hover */
        }

        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% {
                transform: translateY(0);
            }

            40% {
                transform: translateY(-30px);
            }

            60% {
                transform: translateY(-15px);
            }
        }
    </style>
</head>
<body>
<?php
include("manager.php");
?>
<div class="home-content">
    <div class="overview-boxes">
        <div class="box">
            <div class="right-side">
                <div class="box-topic">Daily Sales</div>
                <div class="number">  $<?php echo $dailySales; ?></div>
                <div class="indicator">
                    <i class="bx bx-line-chart"></i>
                    <span class="text">Today</span>
                </div>
            </div>
        </div>
        <div class="box">
            <div class="right-side">
                <div class="box-topic">Weekly Sales</div>
                <div class="number">  $<?php echo $weeklySales; ?></div>
                <div class="indicator">
                    <i class="bx bx-line-chart"></i>
                    <span class="text">Current Week</span>
                </div>
            </div>
        </div>
        <div class="box">
            <div class="right-side">
                <div class="box-topic">Monthly Sales</div>
              <div class="number">  $<?php echo $monthlySales; ?></div>
                <div class="indicator">
                    <i class="bx bx-line-chart"></i>
                    <span class="text">Current Month</span>
                </div>
            </div>
        </div>
        <div class="box">
            <div class="right-side">
                <div class="box-topic">Yearly Sales</div>
                <div class="number">  $<?php echo $yearlySales; ?></div>
                <div class="indicator">
                    <i class="bx bx-line-chart"></i>
                    <span class="text">Current Year</span>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
