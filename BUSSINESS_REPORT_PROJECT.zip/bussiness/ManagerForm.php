<?php
include("connection.php");

if(isset($_POST["insert_user_data"])){
  $good = $_POST['good'];
  $quantity= $_POST['quantity'];
  $cost= $_POST['cost'];
  $date= $_POST['date'];

  $enroll_new_stock = "INSERT INTO  stock(good,quantity,cost,date) VALUES('$good','$quantity','$cost','$date');";

  if (mysqli_query($conn,$enroll_new_stock )) {
    echo "<script>window.location='managerform.php'</script>";
  } else {
    echo "wrong  try again";
  }

  mysqli_close($conn);
}
?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>stockform</title>
    <style>
        .form {
            display: block;
            background-color: white;
            height: 800px;
            width: 1400px;
            margin-left: 30px;
            padding-left: 50px; /* Adjust left padding */
            margin-top: 50px;
        }

        input, select {
            padding: 15px; /* Adjust padding */
            color: black;
            background-color: transparent;
            margin-left: 0px;
            font-size: 25px;
            text-align: left;
            border-color: whitesmoke;
            width: 1300px; /* Take up full width */
            box-sizing: border-box; /* Ensure padding and border are included in the width */
        }

        h1 {
            font-size: 30px;
            text-align: center;
            color: black;
        }

        h2 {
            font-size: 30px;
        }

        p {
            color: purple;
        }

    </style>
</head>
<body>
    <?php
    include("manager.php");
    ?>

    <div class="form">
        <form action="" method="post">
            <h1>Please fill the boxes below</h1>
            <br><br>
            <label><h2>*Good Type</h2></label>
            <select name="good" id="good" required>
                <option>Wheat</option>
                <option>Flower</option>
                <option>Oil</option>
                <option>Rice</option>
                <option>Soda</option>
                <option>Supergates</option>
                <option>Beans</option>
                <option>Apples</option>
                <option>Juices</option>
                <option>Lotion</option>
                <option>Biscuits</option>
            </select>
            <br>
            <label><h2>*Quantity</h2></label><br>
            <input type="text" name="quantity" placeholder="" required>
            <br>
            <label><h2>*Cost</h2></label><br>
            <input type="text" name="cost"  placeholder="" required>
            <br>
            <label><h2>*Date</h2></label><br>
            <input type="date" name="date" placeholder="" required>
            <br><br>
            <div class="button">
            <button type="submit" name="insert_user_data" class="btn btn-primary">Upload</button>
            </div>
        </form>
    </div>
</body>
</html>
