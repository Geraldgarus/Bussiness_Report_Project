<?php
include("connection.php");

if(isset($_POST["insert_user_data"])){
  $good = $_POST['good'];
  $quantity= $_POST['quantity'];
  $cost= $_POST['cost'];
  $date= $_POST['date'];
 
  $enroll_new_patient = "INSERT INTO  sales(good,quantity,cost,date) VALUES('$good','$quantity','$cost','$date');";

  if (mysqli_query($conn,$enroll_new_patient )) {
    echo "<script>window.location='salesform.php'</script>";
  } else {
    echo "wrong  try again";
  }

  mysqli_close($conn);
}
?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>salesaform</title>
    <style>
        .form {
            display: block;
            background-color:white;
            height:800px;
            width: 1600px;
            margin-left: 10px;
            padding-left: 50px;
            margin-top: 50px;
            position: fixed;
        }
        input, select {
            padding: 10px;
            color: black;
            background-color: transparent;
            margin-left: 0px;
            font-size: 25px;
            text-align: left;
            border-color:whitesmoke;
            width: 1500px;
            box-sizing: border-box; /* Ensure padding and border are included in the width */
        }
        h1 {
            font-size: 30px;
            text-align: center;
            color: black;
        }
    
        h2 {
            font-size: 30px;
        }
        p {
             color: purple;
        }
    </style>
</head>
<body>
    <?php
    include("seller.php");
    ?>

    <div class="form">
        <form action="" method="post">
            <h1>please fill the box below</h1>
            <br><br>
            <label><h2>*GoodType</h2></label><br>
            <select name="good" id="good" required>
                <option>Wheat</option>
                <option>Frower</option>
                <option>Oil</option>
                <option>Rice</option>
                <option>soda</option>
                <option>Supergates</option>
                <option>Beans</option>
                <option>Apples</option>
                <option>Juices</option>
                <option>Lotion</option>
                <option>Biscuits</option>
            </select>
            <br>
            <label><h2>*Quantity</h2></label><br>
            <input type="text" name="quantity" placeholder="" required>
            <br>
            <label><h2>*Cost</h2></label><br>
            <input type="text" name="cost"  placeholder="" required>
            <br>
            <label><h2>*Date</h2></label><br>
            <input type="date" name="date" placeholder="" required>
            <br><br>
            <button type="submit" name="insert_user_data" class="btn btn-primary">submit</button>
        </form>
    </div>
</body>
</html>
